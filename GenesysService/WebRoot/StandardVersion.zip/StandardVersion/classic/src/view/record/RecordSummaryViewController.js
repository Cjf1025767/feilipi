Ext.define('Tab.view.record.RecordSummaryViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.record-recordsummaryview'

});
