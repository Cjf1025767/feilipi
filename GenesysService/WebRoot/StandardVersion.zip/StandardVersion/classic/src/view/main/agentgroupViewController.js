Ext.define('Tab.view.main.agentgroupViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main-agentgroupview'

});
