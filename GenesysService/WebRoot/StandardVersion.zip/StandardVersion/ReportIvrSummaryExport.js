var Exports = Object();
Exports.Name = function(){return ""};
Exports.Header = function(){return [
	["nyear","Time"],
	["department","Department"],
	["ninboundcount","InBoundCount"],
	["nnoanswercount","NoAnswerCount"],
	["AnsweredRate","AnsweredRate"],
	["nnoanswerlength","AnandonedWhileQueue"],
	["nnoivranswerlength","AnandonedWhileIvr"],
	["ninboundwait","InBoundWait(average)"],
	["nnoanswerwait","NoAnswerWait(average)"],
	["ninboundlength","IVRLength(average)"],
	["nmonth", ""],
	["nday", ""],
	["nnoanswercount",""],
	["ninboundcount",""],
	["nnnoanswerlength",""]
];}

Exports.Values = function(records,h)
{
	var lst = new Array();
	for(var i = 0 ; i < records.size() ; i++){
		switch(i){
		case 0:
			lst[i] = records.get(i) + '-' + records.get(h.indexOf('nmonth')) + '-' + records.get(h.indexOf('nday')) ;
			break;
		case 1:
			lst[i] = records.get(i);
			break;
		case 2:
			lst[i] = records.get(i);
			break;
		case 3:
			lst[i] = records.get(i);
			break;
		case 4 :
			if(records.get(h.indexOf('ninboundcount'))==0)
				lst[i] = '0%';
			else
				lst[i] = Math.round((records.get(h.indexOf('ninboundcount')) / (records.get(h.indexOf('ninboundcount')) + records.get(h.indexOf('nnoanswercount')) + records.get(h.indexOf('nnnoanswerlength')) + records.get(h.indexOf('nnoanswerlength')))) * 10000) / 100.0 + '%';
			break;
		case 5:
			lst[i] = records.get(i);
			break;
		case 6:
			lst[i] = records.get(i);
			break;
		case 7:
			lst[i] = standartCalculateLength(records.get(i));
			break;
		case 8:
			lst[i] = standartCalculateLength(records.get(i));
			break;
		case 9:
			lst[i] = standartCalculateLength(records.get(i))
		// case 1:
		// 	lst[i] = (records.get(i) == null || records.get(i) =="")? records.get(h.indexOf('department')):records.get(i);
		// 	break;
		// case 2:
		// 	lst[i] = parseInt(records.get(i)) + parseInt(records.get(h.indexOf('nNoAnswerCount'))) + parseInt(records.get(h.indexOf('nOutboundCount'))) + parseInt(records.get(h.indexOf('nNoConnectCount')));
		// 	break;
		// case 5:
		// 	var v1 = records.get(i) + records.get(h.indexOf('nNoAnswerCount')),
		// 	nNo = records.get(h.indexOf('nNoAnswerWait')) == null? 0:records.get(h.indexOf('nNoAnswerWait')),
		// 	nIn	= records.get(h.indexOf('nInboundWait')) == null? 0:records.get(h.indexOf('nInboundWait'));					
		// 	var v2 = nNo + nIn;
		// 	if(v2 >0){
		// 		lst[i]= "\t" + standartCalculateLength(v2/v1);
		// 	}else{
		// 		lst[i]= "\t" + "00:00:00";
		// 	}
		// 	break; 
		// case 6:
		// 	var inRing = records.get(i) == null? 0:records.get(i),
		// 		inWait = records.get(h.indexOf('nInboundWait')) == null? 0:records.get(h.indexOf('nInboundWait')),
		// 		totalRing = inRing + inWait;
		// 	if(totalRing == 0){
		// 		lst[i]= "\t"+ "00:00:00";
		// 	}else{
		// 		lst[i] = "\t" + standartCalculateLength(totalRing);
		// 	}
		// 	break;
		// case 7:
		// 	lst[i] = "\t" + standartCalculateLength(records.get(i));
		// 	break;
		
		}
	}
	return lst;
}
function standartCalculateLength(d){
	var hour = Math.floor(d/(3600));//小时
	var h = d%(3600);
	var minute=Math.floor(h/(60)) ;//分钟
	var m = h%(60); 
	var second=Math.floor(m) ;
	var hh = (hour < 10 ? "0" + hour : hour)
	var mm = (minute < 10 ? "0" + minute : minute)
	var ss = (second < 10 ? "0" + second : second)
	return hh+":"+mm+":"+ss;
}

