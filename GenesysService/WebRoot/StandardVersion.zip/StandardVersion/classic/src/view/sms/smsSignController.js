Ext.define('Tab.view.sms.smsSignController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.sms-smssign'

});
