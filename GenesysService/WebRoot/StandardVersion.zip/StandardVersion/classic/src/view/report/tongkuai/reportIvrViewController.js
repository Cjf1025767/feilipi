Ext.define('Tab.view.report.reportIvrViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.report-reportivrview'

});
