Ext.define('Tab.view.record.RecordSummaryViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.record-recordsummaryview',
    data: {
        name: 'Tab'
    }

});
