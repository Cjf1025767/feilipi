var Exports = Object();
Exports.Name = function(){return ""};
Exports.Header = function(){return [
	["department","department"],
	["begintime","Time"],
	["channel","Agent"],
	["ani","Caller"],
	["dnis","Called"],
	["type","Situation"],
	["ringtime","RingTime"],
	["endtime","EndTime"],
	["queuetime","QueueTime"],
	["wait","Wait"],
];}

Exports.Values = function(records,h)
{
	var lst = new Array();
	for(var i = 0 ; i < records.size() ; i++){
		switch(i){
		case 0:
			lst[i] = (records.get(i) == null || records.get(i) =="")? records.get(h.indexOf('department')):records.get(i);
			break;
		case 1:
			lst[i] = (records.get(i) == null || records.get(i));
			break;
		case 3:
			lst[i] = (records.get(i) == null || records.get(i) == "")? records.get(h.indexOf('ani')):records.get(i);
			break;
		case 4:
			lst[i] = "\t" + records.get(i);
			break;
		case 5:
			switch(records.get(i)){
			case 'Abandoned':    
            case 'CustomerAbandoned':
            case 'Redirected':
                return "NoAnswered";
            case 'IVR':
                return "AutomaticVoice";
            case 'AbandonedWhileQueued':
                return 'NoAnswerWait';
            case 'Pulled':
            case 'None':
            case 'Incomplete':
            case 'OutboundStopped':
            case 'Transferred':
            case 'Diverted':
            case 'DestinationBusy':
            case 'Conferenced':
            case 'Cleared':
            case 'Routed':
            case 'AbnormalStop':
            case 'Deferred':
                return value;
            case 'Completed':
                return "Answer";
			}
			break;
		case 6:
			lst[i] = ("\t"+ records.get(i)).substring(11,20);
			break;
		case 7:
			lst[i] = ("\t"+ records.get(i)).substring(11,20);
			break;
		case 8:
			lst[i] = standartCalculateLength(records.get(i));
			break;
		}
	}
	return lst;
}