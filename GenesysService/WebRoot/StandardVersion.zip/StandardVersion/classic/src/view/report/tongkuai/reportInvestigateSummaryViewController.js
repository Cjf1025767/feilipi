Ext.define('Tab.view.report.reportInvestigateSummaryViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.report-reportinvestigatesummaryview'

});
