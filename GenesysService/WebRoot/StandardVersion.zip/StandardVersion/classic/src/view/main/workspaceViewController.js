Ext.define('Tab.view.main.workspaceViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main-workspaceview'

});
