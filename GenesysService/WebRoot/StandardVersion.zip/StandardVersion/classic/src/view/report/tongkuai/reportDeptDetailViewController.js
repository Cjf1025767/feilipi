Ext.define('Tab.view.report.reportDetailViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.report-reportDetailViewController'

});
