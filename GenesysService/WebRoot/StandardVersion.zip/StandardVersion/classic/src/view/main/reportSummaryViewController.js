Ext.define('Tab.view.main.reportSummaryViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main-reportsummaryview'

});
