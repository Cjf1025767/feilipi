Ext.define('Tab.view.dashboard.ServicesViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.services',

    data: {
        finance: 0.2,
        marketing: 0.12,
        research: 0.68
    }
});
