Ext.define('Tab.view.main.appTrunkViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main-apptrunkview'

});
