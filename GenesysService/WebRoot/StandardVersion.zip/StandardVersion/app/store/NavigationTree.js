Ext.define('Tab.store.NavigationTree', {
    extend: 'Ext.data.TreeStore',

    storeId: 'NavigationTree',

    fields: [{
        name: 'text'
    }],

    root: {
        expanded: true,
        children: [
            {
                text: 'Recording query',
                iconCls: 'x-fa fa-file-audio-o',
//                selectable: false,
//                expanded: false,
                resourceId: "45BBBF87-25B8-492A-B206-CC55F3E4903C", //录音查询
                viewType: 'searchrecordview',
                leaf: true
//                children: [{
//                    text: 'Recording query',
//                    iconCls: 'x-fa fa-file-audio-o',
//                    routeId: 'searchrecord',
//                    viewType: 'searchrecordview',
//                    leaf: true
//                }, {
//                    text: 'Recording summary',
//                    iconCls: 'x-fa fa-bar-chart',
//                    routeId: 'recordsummaryview',
//                    viewType: 'recordsummaryview',
//                    leaf: true
//                }]
            },
            // {
            //     text: 'voicemail query',
            //     iconCls: 'x-fa fa-file-audio-o',
            //     resourceId: "45BBBF87-25B8-492A-B206-CC55F3E4903C", //语音信箱
            //     viewType: 'voicemailview',
            //     leaf: true
            // },
            {
                text: 'Holiday',
                iconCls: 'x-fa fa-users',
                routeId: 'holidayView',
                viewType: 'holidayView',
                resourceId: "952C8D60-4F8A-11EB-B5EB-00155D782604", //假日配置
                leaf: true
            },
            {
            	text: 'Monitor',
                iconCls: 'x-fa fa-outdent',
                viewType: 'monitorView',
                routeId: 'monitorView',
                resourceId:'4A16A347-A2CF-11E9-9604-54E1AD6C1F93',//分机监控
                leaf: true
            },
            {
                text: 'Comprehensive ',
                iconCls: 'x-fa fa-line-chart',
                selectable: false,
                expanded: false,
                children: [
                {
                    text: 'Report Agent Of Department Detail ',
                    iconCls: 'x-fa fa-list',
                    viewType: 'reportDeptDetailView',
                    routeId: 'reportDeptDetailView',
                    resourceId: 'BBFED234-B994-11E9-9EA9-54E1AD6C1F93',
                    leaf: true
                }, 
              
                // {
                // 	text:'No Answered Call',
                // 	iconCls:'x-fa fa-list',
                // 	viewType: 'NoAnsweredCall',
                // 	routeId: 'NoAnsweredCall',
                // 	resourceId: 'BBFED234-B994-11E9-9EA9-54E1AD6C1F93',
                // 	leaf:true
                // },
                {
                    text: 'Report IVR Summary',
                    iconCls: 'x-fa fa-list',
                    viewType: 'reportIvrSummary',
                    routeId: 'reportIvrSummary',
                    resourceId: 'BBFED234-B994-11E9-9EA9-54E1AD6C1F93',
                    leaf: true
                },
                // {
                // 	text:'Report IVR',
                // 	iconCls:'x-fa fa-list',
                // 	viewType: 'reportIvrView',
                // 	routeId: 'reportIvrView',
                // 	resourceId: 'BBFED234-B994-11E9-9EA9-54E1AD6C1F93',
                // 	leaf:true
                // },
                {
                	text:'Satisfaction Summary Agent',
                	iconCls:'x-fa fa-list',
                	viewType: 'reportInvestigateSummaryView',
                	routeId: 'reportInvestigateSummaryView',
                	resourceId: 'BBFED234-B994-11E9-9EA9-54E1AD6C1F93',
                	leaf:true
                },

                {
                	text:'Satisfaction Summary Dept',
                	iconCls:'x-fa fa-list',
                	viewType: 'reportDeptInvestigateSummaryView',
                	routeId: 'reportDeptInvestigateSummaryView',
                	resourceId: 'BBFED234-B994-11E9-9EA9-54E1AD6C1F93',
                	leaf:true
                },
                
            ]
            },
        ]
    }
});