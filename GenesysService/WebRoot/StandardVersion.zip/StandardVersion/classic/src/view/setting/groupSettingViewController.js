Ext.define('Tab.view.setting.groupSettingViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.setting-groupsettingview'

});