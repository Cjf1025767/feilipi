Ext.define('Tab.view.newreport.reportOutDetailViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.newreport-reportoutdetailview'
});
