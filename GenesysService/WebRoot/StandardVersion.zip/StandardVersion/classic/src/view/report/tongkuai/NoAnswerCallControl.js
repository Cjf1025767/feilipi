Ext.define('Tab.view.report.tongkuai.NoAnsweredCallController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.report-NoAnsweredCall'

});
