Ext.define('Tab.view.record.SearchRecordViewController',{
	extend: 'Ext.app.ViewController',
	alias: 'controller.searchrecord'
});