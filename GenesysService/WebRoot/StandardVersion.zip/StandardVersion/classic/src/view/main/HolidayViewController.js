Ext.define('Tab.view.main.HolidayViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main-holidayview'

});
