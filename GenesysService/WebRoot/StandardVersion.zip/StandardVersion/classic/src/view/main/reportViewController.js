Ext.define('Tab.view.main.reportViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main-reportview'

});
