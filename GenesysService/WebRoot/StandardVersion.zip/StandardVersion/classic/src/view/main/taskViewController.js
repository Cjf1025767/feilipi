Ext.define('Tab.view.main.taskViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main-taskview'

});
