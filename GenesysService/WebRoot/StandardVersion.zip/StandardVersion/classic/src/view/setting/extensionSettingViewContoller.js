Ext.define('Tab.view.setting.extensionSettingViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.setting-extensionsettingview'

});