Ext.define('Tab.view.sms.SmsSummaryViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.sms-smssummaryview'

});
