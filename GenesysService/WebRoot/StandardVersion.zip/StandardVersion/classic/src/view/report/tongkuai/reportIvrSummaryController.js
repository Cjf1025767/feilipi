Ext.define('Tab.view.report.reportIvrSummaryController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.report-reportIvrSummary'

});
