var Exports = Object();
Exports.Name = function(){return ""}
Exports.Header = function(){return [
	["ringtime","RingDate&Time"],
	["ani","Caller"],
	["type","Type"],
	["department","Department"],
	["queues","Queues"],
	["channel","Agent"],
	["username","Name"],
	["begintime","StartTime"],
	["endtime","EndTime"],
	["wait","RingWaitTime"],
	["satisfaction","Satisfaction"],
	["length","length"],
];}

Exports.Values = function(records,h)
{
	var lst = new Array();
	for(var i = 0 ; i < records.size() ; i++){
		switch(i){
		default:
			lst[i] = records.get(i);
			break;
//		 case 1:
//		 	lst[i] = "\t" + standartCalculateLength(records.get(i));
//		 	break;
//		 case 2:
//		 	lst[i] = (records.get(i) == null || records.get(i) == "")? records.get(h.indexOf('ani')):records.get(i);
//		 	break;
//		 case 3:
//		 	switch(records.get(i)){
//		 	case "NoAnswered":
//		 		lst[i] = "NoAnswered";
//		 		break;
//		 	case "OutBoundAnswered":
//		 		lst[i] = "OutBoundAnswered";
//		 		break;
//		 	case "InBoundAnswered":
//		 		lst[i] = "InBoundAnswered";
//		 		break;
//		 	case "NoInBoundAnswered":
//		 		lst[i] = "NoInBoundAnswered";
//		 	}
//		 	break;
//		 case 4:
//		 	lst[i] = (records.get(i) == null || records.get(i) =="")? records.get(h.indexOf('department')):records.get(i);
//		 	break; 
//		 case 5:
//		 	lst[i] = (records.get(i) == null || records.get(i) == "")? records.get(h.indexOf('channel')):records.get(i);
//		 	break;
		// case 6:
		// 	lst[i] = (records.get(i) == null || records.get(i) == "")? records.get(h.indexOf('username')):records.get(i);
		// 	break;
		// case 9:
		// 	lst[i] = "\t"+ standartCalculateLength(records.get(i));
		// 	break;
		// case 11:
		// 	lst[i] = "\t"+ standartCalculateLength(records.get(i));
		// 	break;
		 }
	}
	return lst;
}
function standartCalculateLength(d){
	var hour = Math.floor(d/(3600));//小时
	var h = d%(3600);
	var minute=Math.floor(h/(60)) ;//分钟
	var m = h%(60); 
	var second=Math.floor(m) ;
	var hh = (hour < 10 ? "0" + hour : hour)
	var mm = (minute < 10 ? "0" + minute : minute)
	var ss = (second < 10 ? "0" + second : second)
	return hh+":"+mm+":"+ss;
}