var Exports = Object();
Exports.Name = function(){return ""};
Exports.Header = function(){return [
	["department","Department"],
	["nyear","Time"],
	["n1count","Very Satisfied"],
	["n2count","Satisfied"],
	["n3count","Dissatisfied"],
	["n0count","Valid count"],
	["totalscore","Total score"],
	["Averge(Valid)","Averge(Valid)"],
	["ntotalcallcount","Total count"],
	["ntype",""],
	["nmonth", ""],
	["nday", ""],
];}

Exports.Values = function(records,h)
{
	var lst = new Array();
	for(var i = 0 ; i < records.size() ; i++){
		switch(i){
		case 1:
			lst[i] = records.get(i) + '-' + records.get(h.indexOf('nmonth')) + '-' + records.get(h.indexOf('nday')) ;
			break;
		case 5:
			lst[i] = parseInt(records.get(h.indexOf('ntotalcallcount')) - parseInt(records.get(h.indexOf('n0count'))));
			break;
		case 6:
			lst[i] = parseInt(records.get(h.indexOf('n1count')))*2 + parseInt(records.get(h.indexOf('n2count')));
			break;
		case 7:
			if(parseInt(records.get(h.indexOf('ntotalcallcount')) - parseInt(records.get(h.indexOf('n0count')))) == 0 )
				lst[i] = '0';
			else
				lst[i] = (parseInt(parseInt(records.get(h.indexOf('n1count')))*2 + parseInt(records.get(h.indexOf('n2count')))) /  parseInt(records.get(h.indexOf('ntotalcallcount')) - parseInt(records.get(h.indexOf('n0count'))))).toFixed(2)
			break;
		// case 2:
		// 	var tytime = records.get(h.indexOf('nType'));
		// 	if(tyTime==0){
		// 		lst[i] = records.get(i) + 'Year' + records.get(h.indexOf('nMonth')) + 'Month' + records.get(h.indexOf('nDay')) + 'Day' + records.get(h.indexOf('nHour'))+'Hour';
		// 	}else if(tyTime==1){
		// 		lst[i] = records.get(i) + 'Year' + records.get(h.indexOf('nMonth')) + 'Month' + records.get(h.indexOf('nDay'))+ 'Day';
		// 	}else if(tyTime==2){
		// 		lst[i] = records.get(i) + 'Year' + records.get(h.indexOf('nWeek')) + 'Week';
		// 	}else{
		// 		lst[i] = records.get(i) + 'Year' + records.get(h.indexOf('nMonth')) + 'Month';
		// 	}
		// 	break;
		// case 3:
		// 	lst[i] = (records.get(i) == null || records.get(i) == "")? records.get(h.indexOf('businessType')):records.get(i);
		// 	break;
		// case 10:
		// 	lst[i] = parseInt(records.get(h.indexOf('nTotalCallCount')))-parseInt(records.get(h.indexOf('nTotalCallCount')));
		// 	break;
		default:
			lst[i] = records.get(i);
			break;
		}
	}
	return lst;
}
function standartCalculateLength(d){
	var hour = Math.floor(d/(3600));//小时
	var h = d%(3600);
	var minute=Math.floor(h/(60)) ;//分钟
	var m = h%(60); 
	var second=Math.floor(m) ;
	var hh = (hour < 10 ? "0" + hour : hour)
	var mm = (minute < 10 ? "0" + minute : minute)
	var ss = (second < 10 ? "0" + second : second)
	return hh+":"+mm+":"+ss;
}