Ext.define('Tab.view.setting.screenGroupsController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.setting-screengroups'

});